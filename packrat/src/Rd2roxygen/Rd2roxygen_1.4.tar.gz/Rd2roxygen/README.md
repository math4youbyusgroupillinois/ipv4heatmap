# Rd2roxygen

[![Build Status](https://travis-ci.org/yihui/Rd2roxygen.png)](https://travis-ci.org/yihui/Rd2roxygen)

Convert Rd to roxygen documentation. For more information, see <http://yihui.name/Rd2roxygen>.

