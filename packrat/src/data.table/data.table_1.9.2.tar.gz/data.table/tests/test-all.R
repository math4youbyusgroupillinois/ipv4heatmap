library(testthat)
library(data.table)

test_package("data.table")
